USE SKOLADB;
GO

-- Personal
INSERT INTO Personal (Fornamn, Efternamn, Personnummer, Befattning, AnstalldDatum, Manadslon)
VALUES
('Anna','Lind','19800101-1234','L�rare','2010-08-15',35000),
('Bj�rn','Eriksson','19750505-5678','L�rare','2005-08-15',36000),
('Sara','Holm','19891212-2222','Administrat�r','2015-01-10',30000),
('Karin','Berg','19661111-9999','Rektor','2000-08-15',45000);
GO

-- Klasser
INSERT INTO Klass (KlassNamn, AnsvarigLarareID)
VALUES
('NA21A',1),
('TE21B',2);
GO

-- Kurser
INSERT INTO Kurs (KursNamn)
VALUES
('Matematik 1c'),
('Svenska 1'),
('Fysik 1');
GO

-- Studenter
INSERT INTO Student (Fornamn, Efternamn, Personnummer, KlassID)
VALUES
('Maja','Svensson','20040123-1111',1),
('Liam','Andersson','20040210-2222',1),
('Ella','Johansson','20040515-3333',2),
('Noah','Karlsson','20040312-4444',2);
GO

-- Betyg
INSERT INTO Betyg (StudentID, KursID, LarareID, Betyg, Datum)
VALUES
(1,1,1,'A','2025-01-10'),
(1,2,1,'B','2025-02-05'),
(2,1,1,'C','2025-02-03'),
(3,3,2,'A','2025-02-20');
GO

CREATE PROCEDURE VisaStudentInfo
    @StudentID INT
AS
BEGIN
    -- Info om student
    SELECT S.Fornamn, S.Efternamn, S.Personnummer, K.KlassNamn
    FROM Student S
    JOIN Klass K ON S.KlassID = K.KlassID
    WHERE S.StudentID = @StudentID;

    -- Betyg f�r studenten
    SELECT B.BetygID, Ku.KursNamn, B.Betyg, P.Fornamn + ' ' + P.Efternamn AS Larare, B.Datum
    FROM Betyg B
    JOIN Kurs Ku ON B.KursID = Ku.KursID
    JOIN Personal P ON B.LarareID = P.PersonalID
    WHERE B.StudentID = @StudentID;
END;
GO
